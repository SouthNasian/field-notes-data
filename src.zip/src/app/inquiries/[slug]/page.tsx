import { notFound } from "next/navigation";
import { ArticleShell } from "@/components/ArticleShell";
import { inquiries } from "@/lib/sampleContent";
import { VisualPlaceholder } from "@/components/VisualPlaceholder";

export default async function InquiryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const item = inquiries.find(x => x.slug === slug);
  if (!item) notFound();
  return (
    <ArticleShell type="Inquiry" number={item.number} eyebrow={item.eyebrow} title={item.title} dek={item.summary} date={item.date} visual={item.visual}>
      <section id="opening"><p className="eyebrow">THE QUESTION</p><h2>It started with something I wanted to understand.</h2><p>This V1 sample shows the Data Story structure selected for Inquiries. Real posts will open conversationally, explain why the question matters, and move quickly into the evidence rather than reading like an academic report.</p></section>
      <section><p className="eyebrow">FIRST, I NEEDED DATA</p><h2>What information could actually answer the question?</h2><p>Here the article introduces public datasets, variables, assumptions, and important limitations in plain language.</p><VisualPlaceholder type="chart" label="Dataset or exploratory visual" /></section>
      <section id="middle"><p className="eyebrow">THE FIRST SURPRISE</p><h2>The interesting part is usually where expectations and evidence diverge.</h2><p>An Inquiry unfolds through discoveries. Additional sections can be added or removed depending on the investigation.</p><VisualPlaceholder type="map" label="Intermediate finding" /></section>
      <section id="answer"><p className="eyebrow">WHAT I FOUND</p><h2>The answer should be clear enough to remember.</h2><p>Summarize the evidence, distinguish observation from interpretation, and make uncertainty visible.</p></section>
      <section id="methods" className="methods-box"><p className="eyebrow">BEHIND THE INQUIRY</p><h2>Data · Methods · Tools · AI Assistance</h2><p>This section documents sources, analytical methods, ChatGPT's role, validation steps, and reproducibility details for readers who want to go deeper.</p></section>
    </ArticleShell>
  );
}
