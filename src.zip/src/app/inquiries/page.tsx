import { ContentCard } from "@/components/ContentCard";
import { inquiries } from "@/lib/sampleContent";

export const metadata = { title: "Inquiries" };

export default function InquiriesPage() {
  return (
    <main className="shell page">
      <header className="page-header">
        <p className="eyebrow">INQUIRIES</p>
        <h1>Questions worth investigating.</h1>
        <p>Explored through data, AI, visualization, and a willingness to follow the interesting parts.</p>
      </header>
      <div className="filters">
        {["All", "Business", "Travel", "Grappling", "Hunting", "Dogs", "Visualization"].map(x => <button key={x}>{x}</button>)}
      </div>
      <div className="archive-grid">{inquiries.map(item => <ContentCard key={item.slug} item={item} />)}</div>
    </main>
  );
}
