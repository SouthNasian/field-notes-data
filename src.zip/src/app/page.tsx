import Link from "next/link";
import { ContentCard } from "@/components/ContentCard";
import { VisualPlaceholder } from "@/components/VisualPlaceholder";
import { inquiries, fieldNotes, caseStudies, latest } from "@/lib/sampleContent";

export default function Home() {
  return (
    <main>
      <section className="hero shell">
        <div className="hero-grid">
          <div>
            <p className="eyebrow">DIGITAL EXPEDITION LOG · EST. 2026</p>
            <h1>Field Notes <span>&amp;</span> Data</h1>
            <p className="tagline">Curious inquiries. Real data. AI-assisted answers.</p>
            <p className="hero-copy">Exploring business, sport, travel, the outdoors, and everyday questions through data, AI, visualization, and observation.</p>
            <div className="actions">
              <Link className="button primary" href="/inquiries">Explore inquiries</Link>
              <Link className="button ghost" href="/ai-analytics">AI + Analytics →</Link>
            </div>
          </div>
          <div className="hero-map">
            <div className="coordinate">35.7° N / 78.8° W</div>
            <VisualPlaceholder type="map" label="A map for whatever comes next" />
          </div>
        </div>
      </section>

      <section className="section shell">
        <div className="section-head"><div><p className="eyebrow">FEATURED INQUIRY</p><h2>One question worth following farther</h2></div><span>LOG / 001</span></div>
        <div className="feature-grid">
          <VisualPlaceholder type="map" label="Featured inquiry" />
          <div className="feature-copy">
            <p className="eyebrow">INQUIRY 001 · TRAVEL + DATA</p>
            <h2>{inquiries[0].title}</h2>
            <p>{inquiries[0].summary}</p>
            <div className="tag-row">{inquiries[0].tags.map(t => <span key={t}>{t}</span>)}</div>
            <Link className="text-link" href={`/inquiries/${inquiries[0].slug}`}>Explore the inquiry →</Link>
          </div>
        </div>
      </section>

      <section className="section shell split-editorial">
        <div>
          <div className="section-head"><div><p className="eyebrow">FROM THE DATA</p><h2>Things I investigated</h2></div><Link href="/inquiries">All inquiries →</Link></div>
          <div className="stack">{inquiries.slice(1).map(i => <ContentCard key={i.slug} item={i} compact />)}</div>
        </div>
        <div>
          <div className="section-head"><div><p className="eyebrow">FROM THE FIELD</p><h2>Things I stopped to notice</h2></div><span>Field notes</span></div>
          <div className="stack">{fieldNotes.map(i => <ContentCard key={i.slug} item={i} compact />)}</div>
        </div>
      </section>

      <section className="professional-band">
        <div className="shell">
          <div className="section-head light"><div><p className="eyebrow">AI + ANALYTICS</p><h2>Professional case studies</h2></div><Link href="/ai-analytics">Explore professional work →</Link></div>
          <div className="case-feature">
            <VisualPlaceholder type="dashboard" label="Case study dashboard" />
            <div>
              <p className="eyebrow">CASE STUDY 001 · SAMPLE</p>
              <h2>{caseStudies[0].title}</h2>
              <p>{caseStudies[0].summary}</p>
              <Link className="button light-button" href={`/case-studies/${caseStudies[0].slug}`}>View case study</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section shell">
        <div className="section-head"><div><p className="eyebrow">CURRENT EXPEDITIONS</p><h2>Questions that may take more than one post</h2></div></div>
        <div className="expedition-grid">
          {["AI + Enterprise Analytics", "Grappling Through Data", "Notes From the Field"].map((x, idx) => (
            <Link className="expedition" href={`/expeditions/${idx === 0 ? "ai-enterprise-analytics" : idx === 1 ? "grappling-through-data" : "notes-from-the-field"}`} key={x}>
              <span>0{idx+1}</span><h3>{x}</h3><p>Ongoing collection →</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="method-band">
        <div className="shell">
          <p className="eyebrow">THE METHOD</p>
          <h2>Curiosity is the starting point.</h2>
          <div className="method-flow">
            {["Question", "Data", "AI", "Analysis", "Visualization", "Insight"].map((x, i) => <div key={x}><b>{String(i+1).padStart(2,"0")}</b><span>{x}</span></div>)}
          </div>
        </div>
      </section>

      <section className="section shell about-teaser">
        <div><p className="eyebrow">ABOUT FIELD NOTES &amp; DATA</p><h2>A place to investigate things professionally—and notice things personally.</h2></div>
        <div><p>The site is designed as both an AI/data visualization portfolio and a personal publication. Inquiries use data to explore questions. Field Notes capture experiences worth reflecting on.</p><Link className="text-link" href="/about">More about the project →</Link></div>
      </section>

      <section className="section shell">
        <div className="section-head"><div><p className="eyebrow">LATEST LOG</p><h2>Recent entries</h2></div></div>
        <div className="latest-list">{latest.slice(0,5).map((item, i) => <div className="latest-row" key={item.slug}><span>{String(i+1).padStart(2,"0")}</span><b>{item.kind}</b><p>{item.title}</p><small>{item.date}</small></div>)}</div>
      </section>
    </main>
  );
}
