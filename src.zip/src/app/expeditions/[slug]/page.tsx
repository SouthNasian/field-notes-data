import Link from "next/link";

export default async function ExpeditionPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const title = slug.split("-").map(x => x.charAt(0).toUpperCase()+x.slice(1)).join(" ");
  return (
    <main className="shell page">
      <header className="page-header"><p className="eyebrow">EXPEDITION · COLLECTION</p><h1>{title}</h1><p>An Expedition groups related Inquiries and Field Notes around a larger subject. V1 includes this placeholder so the collection architecture is ready before the archive grows.</p></header>
      <div className="methods-box"><p className="eyebrow">STATUS</p><h2>Ongoing</h2><p>Future Sanity content will populate this page automatically from posts assigned to this Expedition.</p><Link className="text-link" href="/inquiries">Browse current inquiries →</Link></div>
    </main>
  );
}
