import { notFound } from "next/navigation";
import { ArticleShell } from "@/components/ArticleShell";
import { caseStudies } from "@/lib/sampleContent";
import { VisualPlaceholder } from "@/components/VisualPlaceholder";

export default async function CaseStudyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const item = caseStudies.find(x => x.slug === slug);
  if (!item) notFound();
  return (
    <ArticleShell type="Case Study" number={item.number} eyebrow={item.eyebrow} title={item.title} dek={item.summary} date={item.date} visual="dashboard">
      <section id="opening"><p className="eyebrow">MISSION BRIEF</p><h2>Executive summary first.</h2><div className="brief-grid"><div><b>Challenge</b><span>Declining customer retention</span></div><div><b>Audience</b><span>Executive leadership</span></div><div><b>Decision</b><span>Where to focus intervention</span></div><div><b>Tools</b><span>ChatGPT · SQL · Power BI</span></div></div></section>
      <section><p className="eyebrow">THE DATA PRODUCT</p><h2>Give decision-makers the useful artifact early.</h2><VisualPlaceholder type="dashboard" label="Interactive dashboard or product embed" /></section>
      <section id="middle"><p className="eyebrow">TECHNICAL FIELD LOG</p><h2>Then let technical reviewers go deeper.</h2><p>The lower half of a Case Study covers data modeling, KPI governance, AI workflow, analysis, visualization design, validation, and reproducibility.</p><VisualPlaceholder type="chart" label="Data model or analytical finding" /></section>
      <section><p className="eyebrow">AI WORKFLOW</p><h2>Prompt → output → validation → revision.</h2><p>Case Studies should show where AI accelerated the work and where professional judgment changed, rejected, or constrained the result.</p></section>
      <section id="answer"><p className="eyebrow">HUMAN REVIEW</p><h2>What required judgment?</h2><p>Document metric definitions, modeling decisions, business interpretation, visualization choices, and limitations rather than presenting AI output as automatically authoritative.</p></section>
      <section id="methods" className="methods-box"><p className="eyebrow">REPRODUCIBILITY</p><h2>Dataset · Tools · Prompts · Code</h2><p>Link the public dataset, repository, dashboard, methodology, and selected prompts when the final project is publishable.</p></section>
    </ArticleShell>
  );
}
