import { notFound } from "next/navigation";
import { ArticleShell } from "@/components/ArticleShell";
import { fieldNotes } from "@/lib/sampleContent";
import { VisualPlaceholder } from "@/components/VisualPlaceholder";

export default async function FieldNotePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const item = fieldNotes.find(x => x.slug === slug);
  if (!item) notFound();
  return (
    <ArticleShell type="Field Note" number={item.number} eyebrow={item.eyebrow} title={item.title} dek={item.summary} date={item.date} visual="photo">
      <section id="opening"><p className="eyebrow">THE MOMENT</p><h2>Start with what happened.</h2><p>Field Notes are intentionally more personal and less analytical. This is where the scene, experience, photographs, and narrative have room to breathe.</p><VisualPlaceholder type="photo" label="Field photograph" /></section>
      <section id="middle"><p className="eyebrow">THE OBSERVATION</p><h2>What stood out?</h2><p>Capture something worth noticing: a pattern, mistake, success, unexpected reaction, place, or detail.</p></section>
      <section><p className="eyebrow">THE REFLECTION</p><h2>Why did it stick with me?</h2><p>The reflection connects the experience to how you think about it now without forcing every entry to become a data project.</p></section>
      <section id="answer"><p className="eyebrow">THE LESSON · OPTIONAL</p><h2>What might change next time?</h2><p>If there is a genuine lesson, record it. If not, the article can simply end with the reflection.</p></section>
      <section id="methods" className="methods-box"><p className="eyebrow">FIELD DETAILS</p><h2>Context without clutter.</h2><p>Date, location, activity, conditions, event, division, route, or other metadata can change according to the subject.</p></section>
    </ArticleShell>
  );
}
